$(document).ready(function() {
	const distanceToNextImage = -450;
	let currentImageNumber = 0;

	// YOUR CODE HERE

	
	// OTHER CODE
	// This closes the lightbox when you click on the overlay or the x.
	$("#overlay, #close").click(function() {
		$("#lightbox").hide();
	})
});