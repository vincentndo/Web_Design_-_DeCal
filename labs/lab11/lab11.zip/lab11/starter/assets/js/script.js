$(document).ready(function()  {

	// PART 1: YOUR CODE HERE

	$(".nav-item").click(function() {

		let buttonName = $(this).text();
		let buttonActive = $(this).hasClass("active");

		// UNCOMMENT THE SECTION BELOW FOR PART 2
		
		/*
		
		// YOUR CODE HERE - PART 2.1

		if (condition) {
			$(this).addClass("active");
			$(this).removeClass("inactive");

			// YOUR CODE HERE - PART 2.2

		} else {
			$(this).addClass("inactive");
			$(this).removeClass("active");

			// YOUR CODE HERE - PART 2.2

		} 
		*/
		
	})
})